# Quiz-App
A Simple Html &amp; Css &amp; Js Quiz App
<br>
<br>
<img src="/images/test.PNG">
